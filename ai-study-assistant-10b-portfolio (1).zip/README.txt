AI STUDY ASSISTANT — 10-B PORTFOLIO
==================================

FILES
- index.html: complete responsive portfolio website (HTML, CSS and JavaScript in one file)

HOW TO PREVIEW
1. Extract the ZIP file.
2. Open index.html in Chrome, Edge or another browser.
3. Internet is needed for the optional Google Fonts. The site itself works without them.

HOW TO PUBLISH WITH GITHUB PAGES
1. Create a new GitHub repository, for example: ai-study-assistant-portfolio-10b
2. Upload index.html to the repository root.
3. Open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select main and /(root), then Save.
6. Wait for the published URL shown by GitHub Pages.

IMPORTANT CUSTOMIZATION BEFORE SUBMISSION
- Replace the illustrative interface graphic with actual screenshots of your application.
- Verify the exact technologies and features from your 10-A source code before listing them.
- Add your real test results and documentation link.
- Do not upload API keys, passwords, or private information.
- The portfolio does not display or mention the design reference person's name.
